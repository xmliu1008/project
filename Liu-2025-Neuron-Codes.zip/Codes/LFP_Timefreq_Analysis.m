%% LFP_Timefreq_Analysis
clear;clc;close all;
NeuralCircuit='SC-VTA-BLA-Inh';
cd('E:\Summarize Data')
load([NeuralCircuit,'_LFP'])
cc=0;
for sub=1:length(MeanLFPtrial)
    sub
    MM=MeanLFPtrial{sub};
    Step=100;Win=1000;
    for chan=1:size(MM,1)
        cc=cc+1;
        for tt=1:90
            dd=MM(chan,Step*(tt-1)+1:Step*tt+Win);
            MeanS1(cc,tt,:)=Multi_Taper_Fourier_Transform_HCL(dd,1000,100,1,[3,5]);
        end
        LFPTrace{1}(cc,:)=MM(chan,:);
    end
end