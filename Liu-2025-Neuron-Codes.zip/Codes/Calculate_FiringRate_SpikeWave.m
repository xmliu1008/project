%% Calculate_FiringRate_SpikeWave
clear;clc;close all;
cc=0;cc2=0;
MeanSUAtrialBinAll=[];
for sub=1:26
    sub
    cc2=cc2+1;

    Name=c{sub+1,1};
    Marker=floor(cell2mat(c(sub+1,4:end))*1000);Marker(isnan(Marker))=[];
    
    load(['E:\Mat\',Name,'.mat']);

    SRate=1000;
    clear pp SUA SUAtrial MeanSUAtrialBin
    cc1=0;
    for chan=[1:size(allts,2)-2]
        chan
        DD=allts(:,chan);
        WW=allwave(:,chan);
        for ii=1:length(DD)
            pp(ii)=isempty(DD{ii});
        end
        DD1=DD(find(pp==0));
        WW1=WW(find(pp==0));
        
        CellNum=length(DD1);
        CellNum
        
        for  jj=1:CellNum
            DDD=floor(DD1{jj}*1000)+1;
            cc=cc+1;
            cc1=cc1+1;
            dd=zeros(1,floor(Duration*1000));
            dd(DDD)=1;
            SUA(cc1,:)=dd;
            SUAChan(cc)=ceil(chan/4);
            WWW=WW1{jj};
            SUAWaveMean{cc}=mean(WWW);
            SUAWaveTime=0.025:0.025:1.4;
        end
    end
    SRate=1000;
    Len=floor(size(SUA,2)/SRate);
    
    for trial=1:length(Marker)
        SUAtrial(:,trial,:)=SUA(:,Marker(trial)-2*SRate+1:Marker(trial)+8*SRate);
    end
    MeanSUAtrial=squeeze(mean(SUAtrial,2));
    
    Bin=100;
    Len=10000/Bin;
    for jj=1:Len
        MeanSUAtrialBin(:,jj)=mean(MeanSUAtrial(:,(jj-1)*Bin+1:jj*Bin),2);
    end
    
    MeanSUAtrialBinAll=[MeanSUAtrialBinAll;MeanSUAtrialBin];
    
end

DataInfo.MeanSUAtrialBinAll=MeanSUAtrialBinAll;
DataInfo.BinTT=-1.9:0.1:8;
DataInfo.SUAWaveMean=SUAWaveMean;