%% Calculate_LFP_Trace
clear;clc;close all;

cc2=0;
for sub=1:26
    sub
    cc2=cc2+1;

    Name=c{sub+1,1};

    load(['E:\Mat\',Name,'.mat']);
    
    clear pp SUA SUAtrial MeanSUAtrialBin
    cc1=0;
    
%     SS=cell2mat(adfreq_all);pos=find(SS==40000);

    LFP=cell2mat(allad(1:12))';
    LFP=LFP(:,1:40:end);SRate=1000;
    Marker=floor(cell2mat(c(sub+1,4:end))*SRate);Marker(isnan(Marker))=[];
    
    Len=floor(size(LFP,2)/SRate);
    
    clear LFPtrial
    for trial=1:length(Marker)
        LFPtrial(:,trial,:)=LFP(:,Marker(trial)-2*SRate+1:Marker(trial)+8*SRate);
    end
    MeanLFPtrial{cc2}=squeeze(mean(LFPtrial,2));
    MeanLFPtrialAll{cc2}=squeeze(mean(LFPtrial,2));
end