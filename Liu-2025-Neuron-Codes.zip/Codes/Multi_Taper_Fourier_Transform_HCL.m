%% X 1-dim data(time-response), Fs: Sampling Rate
%% X: 1*n , n :time point
%% Fs: Sampling Rate
%% fpass : Stop Frequency, 60Hz or 100Hz
function [MeanS,S,f]=Multi_Taper_Fourier_Transform_HCL(X,Fs,fpass,time,tapers)
% X=X(ii,:);
% 1
raw_data=X;
params.tapers=tapers;% [3 5]; %%% TW: time-bandwidth (time), K: numbers of tapers
params.fpass=[0 fpass];
params.trialave=1;
params.Fs=Fs;
params.err=[1,0.05];
[S,f,Serr]=mtspectrumc(raw_data,params);
% plot(f,S)
% title('Multi-Tapers FFT');
% xlabel('Hz');
% time=1;
MeanS=[];
for kk=1:fpass*time
    kk1=1/time*kk;
    loc=find(f>kk1-(1/time)&f<kk1);
    maxloc=max(loc);
    minloc=min(loc);
    MeanS(1,kk)=mean(S(minloc:maxloc));
end

end

%% check
% tt=1:0.01:10;
% yy=0.2*sin(2*pi*1*tt)+4*sin(2*pi*0.01*tt); %% 2 comps: one 1Hz, the other one 0.01Hz
% % plot(yy)
% % zz1=filter_data_hcl(yy,100,2,0.5); % remain the high freq
% subplot(121);plot(yy);subplot(122);plot(zz1);
% [MeanS,S,f]=Multi_Taper_Fourier_Transform_HCL(yy,100,20);
% plot(f,S);




